package com.example.u_food_delivery_ui_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
