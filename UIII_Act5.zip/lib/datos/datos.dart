// Flor

import 'package:_food_delivery_ui_practice/modelos/flores.dart';
import 'package:_food_delivery_ui_practice/modelos/orden.dart';
import 'package:_food_delivery_ui_practice/modelos/floreria.dart';
import 'package:_food_delivery_ui_practice/modelos/usuario.dart';

final _arreglo1 = Flores(
    imagenUrlF: "assets/images/arreglo1.png",
    nombreF: "Arreglo1",
    precio: 540.50);

final _arreglo2 = Flores(
    imagenUrlF: "assets/images/arreglo2.png",
    nombreF: "Arreglo2",
    precio: 600.20);

final _arreglo3 = Flores(
    imagenUrlF: "assets/images/arreglo3.png",
    nombreF: "Arreglo3",
    precio: 910.30);

final _arreglo4 = Flores(
    imagenUrlF: "assets/images/arreglo4.png",
    nombreF: "Arreglo4",
    precio: 214.60);

final _arreglo5 = Flores(
    imagenUrlF: "assets/images/arreglo5.png",
    nombreF: "Arreglo5",
    precio: 370.00);

final _arreglo6 = Flores(
    imagenUrlF: "assets/images/arreglo6.png",
    nombreF: "Arreglo6",
    precio: 820.10);

final _arreglo7 = Flores(
    imagenUrlF: "assets/images/arreglo7.png",
    nombreF: "Arreglo7",
    precio: 110.50);

final _arreglo8 = Flores(
    imagenUrlF: "assets/images/arreglo8.png",
    nombreF: "Arreglo8",
    precio: 120.99);

// Floreria

final _floreria0 = Floreria(
    imagenUrl: "assets/images/arreglo13.png",
    nombre: "Cumpleaños",
    direccion: "Cd.Juarez",
    clasificacion: 5,
    menu: [
      _arreglo1,
      _arreglo2,
      _arreglo3,
      _arreglo4,
      _arreglo5,
      _arreglo6,
      _arreglo7,
      _arreglo8
    ]);

final _floreria1 = Floreria(
    imagenUrl: "assets/images/Macetas.png",
    nombre: "Macetas",
    direccion: "Cd.Juarez",
    clasificacion: 4.1,
    menu: [_arreglo2, _arreglo3, _arreglo4, _arreglo5, _arreglo6, _arreglo7]);

final _floreria2 = Floreria(
    imagenUrl: "assets/images/XV'S.png",
    nombre: "XV'S",
    direccion: "Cd.Juarez",
    clasificacion: 5,
    menu: [_arreglo2, _arreglo3, _arreglo5, _arreglo6, _arreglo7, _arreglo8]);

final _floreria3 = Floreria(
    imagenUrl: "assets/images/Bodas.png",
    nombre: "Bodas",
    direccion: "Cd.Juarez",
    clasificacion: 4.3,
    menu: [_arreglo6, _arreglo2, _arreglo6, _arreglo7, _arreglo8]);

final _floreria4 = Floreria(
    imagenUrl: "assets/images/regalo.png",
    nombre: "Regalo",
    direccion: "Cd.Juarez",
    clasificacion: 4.0,
    menu: [_arreglo6, _arreglo4, _arreglo5, _arreglo8]);

// Restaurants List

final List<Floreria> florerias = [
  _floreria0,
  _floreria1,
  _floreria2,
  _floreria3,
  _floreria4
];

// User

final usuarioActual = Usuario(nombreU: "Abril Herrera", pedidosU: [
  Orden(
      floreria: _floreria2, flores: _arreglo2, fecha: "30/05/23", cantidad: 1),
  Orden(
      floreria: _floreria0, flores: _arreglo4, fecha: "30/05/23", cantidad: 3),
  Orden(
      floreria: _floreria1, flores: _arreglo1, fecha: "30/05/23", cantidad: 2),
  Orden(
      floreria: _floreria3, flores: _arreglo8, fecha: "30/05/23", cantidad: 1),
  Orden(floreria: _floreria4, flores: _arreglo5, fecha: "30/05/23", cantidad: 1)
], cartaU: [
  Orden(
      floreria: _floreria2, flores: _arreglo6, fecha: "30/05/23", cantidad: 2),
  Orden(
      floreria: _floreria2, flores: _arreglo3, fecha: "30/05/23", cantidad: 1),
  Orden(
      floreria: _floreria3, flores: _arreglo8, fecha: "30/05/23", cantidad: 1),
  Orden(
      floreria: _floreria4, flores: _arreglo5, fecha: "30/05/23", cantidad: 3),
  Orden(floreria: _floreria1, flores: _arreglo1, fecha: "30/05/23", cantidad: 2)
]);
