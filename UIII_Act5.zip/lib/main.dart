import 'package:_food_delivery_ui_practice/pantallas/inicio_pantalla.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: PantallaInicio(),
  ));
}
