import 'package:_food_delivery_ui_practice/modelos/flores.dart';

class Floreria {
  final String imagenUrl;
  final String nombre;
  final String direccion;
  final double clasificacion;
  final List<Flores> menu;

  Floreria(
      {required this.imagenUrl,
      required this.nombre,
      required this.direccion,
      required this.clasificacion,
      required this.menu});
}
