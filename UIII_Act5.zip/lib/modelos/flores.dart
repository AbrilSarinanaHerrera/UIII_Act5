class Flores {
  final String imagenUrlF;
  final String nombreF;
  final double precio;

  Flores(
      {required this.imagenUrlF, required this.nombreF, required this.precio});
}
