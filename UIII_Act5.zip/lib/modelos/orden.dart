import 'package:_food_delivery_ui_practice/modelos/flores.dart';
import 'package:_food_delivery_ui_practice/modelos/floreria.dart';

class Orden {
  final Floreria floreria;
  final Flores flores;
  final String fecha;
  final int cantidad;

  Orden(
      {required this.floreria,
      required this.flores,
      required this.fecha,
      required this.cantidad});
}
