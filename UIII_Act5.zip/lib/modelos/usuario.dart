import 'package:_food_delivery_ui_practice/modelos/orden.dart';

class Usuario {
  final String nombreU;
  final List<Orden> pedidosU;
  final List<Orden> cartaU;

  Usuario(
      {required this.nombreU, required this.pedidosU, required this.cartaU});
}
